module.exports = {
  extends: ['@moralisweb3'],
  ignorePatterns: ['**/lib/**/*', '**/scripts/**/*'],
  rules: {
    'no-await-in-loop': 'off',
  },
};
