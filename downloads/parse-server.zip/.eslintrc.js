module.exports = {
  extends: ['@moralisweb3'],
  ignorePatterns: ['**/build/**/*', '**/lib/**/*'],
  env: {
    browser: true,
  },
};
