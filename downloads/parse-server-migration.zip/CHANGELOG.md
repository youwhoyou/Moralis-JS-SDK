# demo-parse-server-migration

## 1.1.0

### Minor Changes

- [#782](https://github.com/MoralisWeb3/Moralis-JS-SDK/pull/782) [`07c8ca69`](https://github.com/MoralisWeb3/Moralis-JS-SDK/commit/07c8ca6988431d1fdf4a9bce509371ec52174af4) Thanks [@sogunshola](https://github.com/sogunshola)! - Incuded parse server package with streams plugin implementation and added document builder to streams package.

* [#782](https://github.com/MoralisWeb3/Moralis-JS-SDK/pull/782) [`07c8ca69`](https://github.com/MoralisWeb3/Moralis-JS-SDK/commit/07c8ca6988431d1fdf4a9bce509371ec52174af4) Thanks [@sogunshola](https://github.com/sogunshola)! - Included parse server package and added document builder logic to streams package

### Patch Changes

- Updated dependencies [[`07c8ca69`](https://github.com/MoralisWeb3/Moralis-JS-SDK/commit/07c8ca6988431d1fdf4a9bce509371ec52174af4), [`07c8ca69`](https://github.com/MoralisWeb3/Moralis-JS-SDK/commit/07c8ca6988431d1fdf4a9bce509371ec52174af4)]:
  - @moralisweb3/parse-server@2.7.0
  - moralis@2.7.0
  - @moralisweb3/core@2.7.0
